#coursera getting cleaning data

This document contains information regarding the steps taken in run_analysis.R to produce tidy.txt.

The run_analysis script assumes you have access to all source data files in R Studio.

Please ensure you have set your working directory to the correct path to access these files.


Script Breakdown:

1.  Load features; features correlate to column names in the resulting data set.

2.  Filter 'features' to only include values containing 'mean' OR 'std'.

3.  Load train data (consists of x_train, y_train and subject_train data sets).
    Take note x_train subsets the raw data; only including columns found in the filter features derived in step 2.

4.  Load test data (consists of x_test, y_test and subject_test data sets).
    Take note x_test subsets the raw data; only including columns found in the filter features derived in step 2.

5.  Merge both data sets (train_data, test_data) to form one data set; this uses rbind()

6.  Apply column names to the merged data set; column names consist of "activity, subject" and the filtered feature values dervie in step 2.

7.  Load activity labels, and replace the numeric activity codes in the merged data, with their string description counterparts.

8.  Group the data by 'activity' and 'subject', then summarise each column using the mean function.
    This grouped/summarized data set represents the data found in 'tidy.txt'; out tidy data set.